# Angular Plugin Architecture Example
This project represents an example of how to achieve a plugin architecture in angular.

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.1.4.

# Article related: 

# Setup 
> cd plugins/plugin-a

> npm install

> npm run build

------

> cd core-app 

> npm install

> npm start
